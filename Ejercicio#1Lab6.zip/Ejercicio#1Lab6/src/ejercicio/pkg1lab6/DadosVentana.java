package ejercicio.pkg1lab6;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import javax.swing.ImageIcon;
public class DadosVentana extends javax.swing.JFrame {

    public DadosVentana() {
        initComponents();
    }
    
    String [] DadosCaras = {"dados1.jpg","dados2.jpg","dados3.jpg","dados4.jpg","dados5.jpg","dados6.jpg"};
    Timer timer = new Timer();
    Random random = new Random();
    int NumRand, NumRand2;
    Hilo1 hilo = new Hilo1();
    
    TimerTask task = new TimerTask(){
        @Override
        public void run(){
                NumRand = random.nextInt(0, 6);
                NumRand2 = random.nextInt(0, 6);
                Dado1Label.setIcon(new ImageIcon("Imagenes/" + DadosCaras[NumRand]));
                Dado2Label.setIcon(new ImageIcon("Imagenes/" + DadosCaras[NumRand2]));
        }
    };  
          
    public class Hilo1 extends Thread{
        @Override
        public void run(){
        timer.scheduleAtFixedRate(task, 0, 1);
        }
   }
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Dado2Label = new javax.swing.JLabel();
        Dado1Label = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        RodarButton = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Dado2Label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/dados4.jpg"))); // NOI18N
        Dado2Label.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        Dado1Label.setIcon(new javax.swing.ImageIcon(getClass().getResource("/Imagenes/dados1.jpg"))); // NOI18N
        Dado1Label.setBorder(javax.swing.BorderFactory.createLineBorder(new java.awt.Color(0, 0, 0)));

        jLabel3.setFont(new java.awt.Font("Segoe UI", 3, 24)); // NOI18N
        jLabel3.setText("Dados");

        RodarButton.setText("Rodar");
        RodarButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RodarButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(31, 31, 31)
                        .addComponent(Dado1Label)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Dado2Label))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(101, 101, 101)
                        .addComponent(RodarButton)))
                .addGap(0, 51, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGap(107, 107, 107)
                .addComponent(jLabel3)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel3)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(Dado2Label)
                    .addComponent(Dado1Label))
                .addGap(28, 28, 28)
                .addComponent(RodarButton)
                .addContainerGap(23, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void RodarButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RodarButtonActionPerformed
    hilo.start();
   
    }//GEN-LAST:event_RodarButtonActionPerformed

 
    public static void main(String args[]) {
       
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DadosVentana().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel Dado1Label;
    private javax.swing.JLabel Dado2Label;
    private javax.swing.JButton RodarButton;
    private javax.swing.JLabel jLabel3;
    // End of variables declaration//GEN-END:variables
}
